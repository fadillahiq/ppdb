
<!-- Err Siswa -->
<div class="<?php echo $nisnClass; ?>" role="alert">
  <span class="<?php echo $nisnClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
<?php echo"$nisnErr";?>
</div>
<div class="<?php echo $nama_siswaClass; ?>" role="alert">
  <span class="<?php echo $nama_siswaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$nama_siswaErr";?>
</div>
<div class="<?php echo $jenis_kelaminClass; ?>" role="alert">
  <span class="<?php echo $jenis_kelaminClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$jenis_kelaminErr";?>
</div>
<div class="<?php echo $tempat_lahirClass; ?>" role="alert">
  <span class="<?php echo $tempat_lahirClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$tempat_lahirErr";?>
</div>
<div class="<?php echo $tanggal_lahirClass; ?>" role="alert">
  <span class="<?php echo $tanggal_lahirClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$tanggal_lahirErr";?>
</div>
<div class="<?php echo $agama_siswaClass; ?>" role="alert">
  <span class="<?php echo $agama_siswaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$agama_siswaErr";?>
</div>
<div class="<?php echo $status_keluargaClass; ?>" role="alert">
  <span class="<?php echo $status_keluargaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$status_keluargaErr";?>
</div>
<div class="<?php echo $alamat_siswaClass; ?>" role="alert">
  <span class="<?php echo $alamat_siswaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$alamat_siswaErr";?>
</div>
<div class="<?php echo $hp_siswaClass; ?>" role="alert">
  <span class="<?php echo $hp_siswaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$hp_siswaErr";?>
</div>
<!-- Err Ayah -->
<div class="<?php echo $nama_ayahClass; ?>" role="alert">
  <span class="<?php echo $nama_ayahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$nama_ayahErr";?>
</div>
<div class="<?php echo $pendidikan_ayahClass; ?>" role="alert">
  <span class="<?php echo $pendidikan_ayahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$pendidikan_ayahErr";?>
</div>
<div class="<?php echo $pekerjaan_ayahClass; ?>" role="alert">
  <span class="<?php echo $pekerjaan_ayahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$pekerjaan_ayahErr";?>
</div>
<div class="<?php echo $penghasilan_ayahClass; ?>" role="alert">
  <span class="<?php echo $penghasilan_ayahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$penghasilan_ayahErr";?>
</div>
<div class="<?php echo $hp_ayahClass; ?>" role="alert">
  <span class="<?php echo $hp_ayahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$hp_ayahErr";?>
</div>
<!-- Err Ibu -->
<div class="<?php echo $nama_ibuClass; ?>" role="alert">
  <span class="<?php echo $nama_ibuClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$nama_ibuErr";?>
</div>
<div class="<?php echo $pendidikan_ibuClass; ?>" role="alert">
  <span class="<?php echo $pendidikan_ibuClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$pendidikan_ibuErr";?>
</div>
<div class="<?php echo $pekerjaan_ibuClass; ?>" role="alert">
  <span class="<?php echo $pekerjaan_ibuClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$pekerjaan_ibuErr";?>
</div>
<div class="<?php echo $penghasilan_ibuClass; ?>" role="alert">
  <span class="<?php echo $penghasilan_ibuClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$penghasilan_ibuErr";?>
</div>
<div class="<?php echo $hp_ibuClass; ?>" role="alert">
  <span class="<?php echo $hp_ibuClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$hp_ibuErr";?>
</div>
<!-- Err Wali -->
<div class="<?php echo $nama_waliClass; ?>" role="alert">
  <span class="<?php echo $nama_waliClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$nama_waliErr";?>
</div>
<div class="<?php echo $pendidikan_waliClass; ?>" role="alert">
  <span class="<?php echo $pendidikan_waliClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$pendidikan_waliErr";?>
</div>
<div class="<?php echo $pekerjaan_waliClass; ?>" role="alert">
  <span class="<?php echo $pekerjaan_waliClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$pekerjaan_waliErr";?>
</div>
<div class="<?php echo $penghasilan_waliClass; ?>" role="alert">
  <span class="<?php echo $penghasilan_waliClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$penghasilan_waliErr";?>
</div>
<div class="<?php echo $hp_waliClass; ?>" role="alert">
  <span class="<?php echo $hp_waliClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$hp_waliErr";?>
</div>
<!-- Err Sekolah -->
<div class="<?php echo $npsn_sekolahClass; ?>" role="alert">
  <span class="<?php echo $npsn_sekolahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$npsn_sekolahErr";?>
</div>
<div class="<?php echo $nama_sekolahClass; ?>" role="alert">
  <span class="<?php echo $nama_sekolahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$nama_sekolahErr";?>
</div>
<div class="<?php echo $status_sekolahClass; ?>" role="alert">
  <span class="<?php echo $status_sekolahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$status_sekolahErr";?>
</div>
<div class="<?php echo $model_ujianClass; ?>" role="alert">
  <span class="<?php echo $model_ujianClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$model_ujianErr";?>
</div>
<div class="<?php echo $alamat_sekolahClass; ?>" role="alert">
  <span class="<?php echo $alamat_sekolahClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$alamat_sekolahErr";?>
</div>
<div class="<?php echo $tahun_lulusClass; ?>" role="alert">
  <span class="<?php echo $tahun_lulusClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$tahun_lulusErr";?>
</div>
<!-- Err Nilai -->
<div class="<?php echo $ipaClass; ?>" role="alert">
  <span class="<?php echo $ipaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$ipaErr";?>
</div>
<div class="<?php echo $matematikaClass; ?>" role="alert">
  <span class="<?php echo $matematikaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$matematikaErr";?>
</div>
<div class="<?php echo $bahasa_indonesiaClass; ?>" role="alert">
  <span class="<?php echo $bahasa_indonesiaClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$bahasa_indonesiaErr";?>
</div>
<div class="<?php echo $bahasa_ingrisClass; ?>" role="alert">
  <span class="<?php echo $bahasa_ingrisClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$bahasa_ingrisErr";?>
</div>
<!-- Error End -->
<div class="<?php echo $status_pendaftaranClass; ?>" role="alert">
  <span class="<?php echo $status_pendaftaranClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$status_pendaftaranErr";?>
</div>
<div class="<?php echo $tanggal_pendaftaranClass; ?>" role="alert">
  <span class="<?php echo $tanggal_pendaftaranClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$tanggal_pendaftaranErr";?>
</div>
<div class="<?php echo $berhasil_simpanClass; ?>" role="alert"><?php echo $berhasil_simpan; ?></div>
<div class="<?php echo $gagal_simpanClass; ?>" role="alert">
  <span class="<?php echo $gagal_simpanClass_icon;?>" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  <?php echo"$gagal_simpanErr";?>
</div>















