<section class="col-sm-12">
<div class="page-header"><h3>MAAF PENGUMUMAN MASIH DITUTUP</h3></div>

        <p>Pengumuman akan dibuka jika panitia sudah melakukan verifikasi dan test terhadap semua siswa yang sudah mendaftar. Siswa dapat kembali kehalaman ini, jika <?php echo "$row[nama_sekolah]";?> sudah membuka pengumuman</p>
         <p>Jika sudah mendaftar, silahkan <a href="bukti-pendaftaran">cetak bukti pendaftaran</a> atau <a href="kartu-peserta">kartu peserta</a></p>


</section>